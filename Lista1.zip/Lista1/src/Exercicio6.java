import java.util.ArrayList;
import java.util.List;

public class Exercicio6 {
    public static void main(String[] args) {
        int produto = 15;
        float produtoFloat = 15.0F;
        List<Integer> impares = new ArrayList<>();

        for (int i = 17; i <= 30; i += 2) {
                produto *= i;
                produtoFloat *= i;
                impares.add(i);
        }
        System.out.println("O produto dos numeros impares : " + impares +
                " é com inteiro " + produto + " e com float " + produtoFloat);
    }
}
