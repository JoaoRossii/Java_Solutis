import java.util.Scanner;

public class Exercicio4 {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);

        Double milha, conversao;

        System.out.println("Digite o valor em Milhas: ");
        milha = scanner.nextDouble();

        System.out.println("Processando...");

        conversao = milha * 1609;
        System.out.println("Suas milhas " + milha + " em Km são: " + conversao);
    }
}
