public class Exercicio7 {
    public static void main(String[] args) {
        for (int i = 1; i < 101; i++) {
            if (i % 3 == 0) {

                int divInt = i / 2;

                double divDouble = (double) i /2;

                System.out.println("Divisão do Multiplo de Três: " + i +
                        " Por 2 (int) = " + divInt +
                        ", Por 2 (double) = " + divDouble);
            }
        }
    }
}
