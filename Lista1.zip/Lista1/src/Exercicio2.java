import java.util.Scanner;

public class Exercicio2 {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);

        int valor1, valor2;

        System.out.println("Digite o primeiro Valor: ");
        valor1 = scanner.nextInt();

        System.out.println("Digite o segundo Valor: ");
        valor2 = scanner.nextInt();

        System.out.println("Processando...");

        if (valor1 > valor2) System.out.println("O primeiro valor e maior que o segundo");
        if (valor1 > valor2) System.out.println("O segundo valor e maior que o primeiro");
    }
}
