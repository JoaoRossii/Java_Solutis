import java.util.Locale;
import java.util.Scanner;

public class Exercicio8 {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);

        System.out.println("Digite uma palara: ");

        String palavra = scanner.nextLine();
        String palavraLowerCase = palavra;

        palavraLowerCase = palavraLowerCase.toLowerCase();
        palavraLowerCase = palavraLowerCase.replaceAll(" ", "");

        String palindromo = "";

        for (int i = palavraLowerCase.length() - 1; i >= 0; i--) {
           palindromo += palavraLowerCase.charAt(i);
        }

        if (palavraLowerCase.equals(palindromo)) {
            System.out.println("A palavra/frase '%s' é um palíndromo! ".formatted(palavra));
        } else {
            System.out.println("A palavra/frase '%s' não é um palíndromo! ".formatted(palavra));
        }
    }
}
