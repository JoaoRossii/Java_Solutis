import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

public class Exercicio5 {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        String[] diasDaSemana = {
                "Segunda-Feira",
                "Terça-Feira",
                "Quarta-Feira",
                "Quinta-Feira",
                "Sexta-Feira",
                "Sabado",
                "Domingo"
        };

        int numero;

        System.out.println("Digite um numero de 1 a 7: ");
        numero = scanner.nextInt();

        for (int i = 1; i < 8; i++) {
            if (i == numero) {
                System.out.println("Dia da semana correspondente: " + diasDaSemana[i - 1]);
            }
        }
    }
}
