import java.util.Scanner;

public class Exercicio11 {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);

        System.out.println("Ordenador de palavras e contador de vogais");

        System.out.println("Digite a primeira palavra: ");
        String palavra1 = scanner.nextLine();

        System.out.println("Digite a segunda palavra: ");
        String palavra2 = scanner.nextLine();

        int resultadoComparacao = palavra1.compareTo(palavra2);

        if (resultadoComparacao < 0) {
            System.out.println("Palavras em ordem alfabética: " + palavra1 + " e " + palavra2);
        } else if (resultadoComparacao > 0) {
            System.out.println("Palavras em ordem alfabética: " + palavra2 + " e " + palavra1);
        } else {
            System.out.println("As palavras são iguais: " + palavra1);
        }

        if (palavra1.length() > palavra2.length()) {
            System.out.println("A palavra com maior número de caracteres é: " + palavra1);
        } else if (palavra1.length() < palavra2.length()) {
            System.out.println("A palavra com maior número de caracteres é: " + palavra2);
        } else {
            System.out.println("Ambas as palavras têm o mesmo número de caracteres.");
        }
    }
}
