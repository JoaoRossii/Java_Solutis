import java.util.Scanner;

public class Exercicio9 {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);

        System.out.println("Digite o valor do raio: ");
        Double raio = scanner.nextDouble();
        Double pi = Math.PI;
        Double area = pi * (raio * raio);
        System.out.println("Area arredondada: " + Math.round(area));
    }
}
