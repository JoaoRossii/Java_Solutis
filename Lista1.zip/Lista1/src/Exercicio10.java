public class Exercicio10 {

    public static void contarCaracteres(String texto) {
        int numVogais = 0;
        int numConsoantes = 0;
        int numEspacos = 0;

        texto = texto.toLowerCase();

        for (int i = 0; i < texto.length(); i++) {
            char c = texto.charAt(i);

            if (c == 'a' || c == 'e' || c == 'i' || c == 'o' || c == 'u') {
                numVogais++;
            }
            else if ((c >= 'a' && c <= 'z')) {
                numConsoantes++;
            }
            else if (c == ' ') {
                numEspacos++;
            }
        }

        System.out.println("Quantidade de Vogais: " + numVogais);
        System.out.println("Quantidade de Consoantes: " + numConsoantes);
        System.out.println("Quantidade de Espaços em Branco: " + numEspacos);
    }

    public static void main(String[] args) {
        String texto = "Olá Mundo! Como você está?";
        contarCaracteres(texto);
    }
}
