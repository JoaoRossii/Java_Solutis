import java.util.Scanner;

public class Exercicio12 {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);

        int totalQuilometros = 0;
        int totalLitrosGasolina = 0;

        System.out.println("Quantos tanques serão registrados?");
        int numeroDeTanques = scanner.nextInt();

        for (int i = 1; i <= numeroDeTanques; i++) {
            System.out.println("Digite os dados para o tanque " + i + ":");

            System.out.println("Digite os quilometros dirigidos: ");
            int km = scanner.nextInt();

            System.out.println("Digite os litros de gasolina: ");
            int litros = scanner.nextInt();

            double consumo = (double) km / litros;

            totalQuilometros += km;
            totalLitrosGasolina += litros;

            System.out.printf("Consumo do tanque %d: %.2f km/l\n", i, consumo);
            System.out.printf("Quilometragem combinada até agora: %d km\n", totalQuilometros);
            System.out.printf("Total de combustível consumido até agora: %d litros\n\n", totalQuilometros);
        }
        double mediaConsumoTota = (double) totalQuilometros / totalLitrosGasolina;
        System.out.printf("Consumo médio geral: %.2f km/l\n", mediaConsumoTota);

        scanner.close();
    }
}
