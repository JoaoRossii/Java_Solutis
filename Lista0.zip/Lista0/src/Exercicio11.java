import java.util.Scanner;

public class Exercicio11 {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);

        String parafuso = "Parafuso";
        String porca = "Porca";
        String prego = "Prego";

        System.out.println("Digite o código desejado");

        switch (scanner.nextLine()) {
            case "001":
                System.out.println(parafuso);
                break;
            case "002":
                System.out.println(porca);
                break;
            case "003":
                System.out.println(prego);
                break;
            default:
                System.out.println("Seu código é inválido.");
                break;
        }
    }
}
