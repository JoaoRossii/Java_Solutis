import java.util.Scanner;

public class Exercicio14 {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);

        int contador = 0;
        int soma = 0;

        while (contador < 51) {
           System.out.print("Digite o " + (contador + 1) + "º número: ");
           int numero = scanner.nextInt();

           soma += numero;

           contador++;
        }

        double media = soma / 50.0;

        System.out.println("A média dos 50 números é: " + media);

        scanner.close();
    }
}
