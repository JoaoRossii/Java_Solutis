public class Exercicio10 {
    public static void main(String[] args) {
        int x = 6;
        int y = 4;
        int z = x / y;

        System.out.println(z);
    }
}
