public class Exercicio9 {
    public static void main(String[] args) {
        System.out.println("Bem vindo ao encontrador de quadrados!");

        for (int i = 1; i < 11; i++) {
            System.out.println("O quadrado de " + i + " é " + i * i);
        }
    }
}
