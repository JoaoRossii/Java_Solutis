import java.util.Scanner;

//TIP To <b>Run</b> code, press <shortcut actionId="Run"/> or
// click the <icon src="AllIcons.Actions.Execute"/> icon in the gutter.
public class Exercicio7 {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);

        int a;
        int b;
        int temp;

        System.out.print("Digite o valor de A: ");
        a = scanner.nextInt();

        System.out.print("Digite o valor de B: ");
        b = scanner.nextInt();

        System.out.println("Antes da troca:");
        System.out.println("A = " + a);
        System.out.println("B = " + b);

        temp = a;
        a = b;
        b = temp;

        System.out.println("\nApós a troca:");
        System.out.println("A = " + a);
        System.out.println("B = " + b);

        scanner.close();
    }
}