import java.util.Scanner;

public class Exercicio8 {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);

        int numero;
        System.out.println("Digite o Numero Inteiro:");
        numero = scanner.nextInt();

        if (numero % 2 == 0) {
            System.out.println("Esse número é par!");
        } else {
            System.out.println("Esse número é impar!");
        }
    }
}
