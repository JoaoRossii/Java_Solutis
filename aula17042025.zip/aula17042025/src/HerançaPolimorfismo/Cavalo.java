package HerançaPolimorfismo;

public class Cavalo extends Animal{

    @Override
    public void emitirSom() {
        System.out.println("IHIHIHIHIHI");
    }

    @Override
    public void moverse() {
        System.out.println("Correndo");
    }
}
