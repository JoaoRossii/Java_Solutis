import HerançaPolimorfismo.Cachorro;
import HerançaPolimorfismo.Cavalo;
import HerançaPolimorfismo.Preguica;

public class Main {
    public static void main(String[] args) {
        Preguica preg = new Preguica();
        preg.setIdade(10);
        preg.setNome("Preguiço");

        Cachorro dog = new Cachorro();
        dog.setIdade(7);
        dog.setNome("Ruby");

        Cavalo horse = new Cavalo();
        horse.setIdade(10);
        horse.setNome("Silver");

        // Preguiça
        System.out.println("Preguiça:");
            preg.moverse();
            preg.emitirSom();
        // Cachorro
        System.out.println("\nCachorro:");
            dog.moverse();
            dog.emitirSom();
        // Cavalo
        System.out.println("\nCavalo:");
            horse.moverse();
            horse.emitirSom();
    }
}